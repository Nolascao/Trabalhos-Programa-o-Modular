public interface INivelCliente {
    double valorAPagarCompra (compra Compra); 
    double valorProdutosCompra (vinho Qual); 
    double valorFreteCompra (compra Compra); 
    double consultaVinho (vinho Qual); 
    double getMensalidade ();
}
